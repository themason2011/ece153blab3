#include "stm32l476xx.h"

#include "L3GD20.h"
#include "SPI.h"
#include "SysClock.h"
#include "SysTimer.h"
#include "UART.h"

#include <stdio.h>

typedef struct {
	float x; 
	float y; 
	float z; 
} L3GD20_Data_t;

int main(void){
	System_Clock_Init();   // System Clock = 80 MHz
	SysTick_Init();
	
	// Initialize Gyroscope
	GYRO_Init();  

	// Initialize USART2
	UART2_Init();
	UART2_GPIO_Init();
	USART_Init(USART2);

	while(1) {
		uint8_t new_data = 0; //To check if there is new data
		L3GD20_Data_t axes_data; //Object for printing new data
		uint8_t data_low = 0; //Low 8-bits of an axis data reg
		uint8_t data_high = 0; //High 8-bits of an axis data reg
		int16_t data = 0; //Used for combining low and high regs for axes data
		GYRO_IO_Read(&new_data, L3GD20_STATUS_REG_ADDR, 1); //Read from Status Register
		if((new_data & 0x08) != 0)	{ //If != 0, that means new_data has a 1 bit at ZYXDA so new data is available. Read the axes
			//CHECK WITH TARIK !!!! DO I HAVE TO SET THE STATUS REG BIT TO 0 AFTER I CHECK IT AND IT SAYS THERE IS NEW DATA?	
			//Read and write x axis data
			GYRO_IO_Read(&data_low, L3GD20_OUT_X_L_ADDR, 1); //Read 8-bit low x register
			GYRO_IO_Read(&data_high, L3GD20_OUT_X_H_ADDR, 1); //Read 8-bit high x register
			data = (data_low | (data_high<<8)); //Combine low and high data
			axes_data.x = data*0.07f; //Conversion
			//Read and write y axis data
			GYRO_IO_Read(&data_low, L3GD20_OUT_Y_L_ADDR, 1); //Read 8-bit low y register
			GYRO_IO_Read(&data_high, L3GD20_OUT_Y_H_ADDR, 1); //Read 8-bit high y register
			data = (data_low | (data_high<<8)); //Combine low and high data
			axes_data.y = data*0.07f; //Conversion
			//Read and write z axis data
			GYRO_IO_Read(&data_low, L3GD20_OUT_Z_L_ADDR, 1); //Read 8-bit low z register
			GYRO_IO_Read(&data_high, L3GD20_OUT_Z_H_ADDR, 1); //Read 8-bit high z register
			data = (data_low | (data_high<<8)); //Combine low and high data
			axes_data.z = data*0.07f; //Conversion
			//Print data
			printf("x-axis: %.3f  y-axis: %.3f  z-axis: %.3f  \n", axes_data.x, axes_data.y, axes_data.z); //Print axes data values
		}
		delay(500); // Small delay between receiving measurements
	}
}
