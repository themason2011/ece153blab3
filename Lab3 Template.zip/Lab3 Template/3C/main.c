#include "stm32l476xx.h"

#include "I2C.h"
#include "LCD.h"
#include "SysClock.h"
#include "stdio.h"
	
int main(void) {
	System_Clock_Init(); // System Clock = 80 MHz	
	LCD_Initialization();
	LCD_Clear();
	
	// Initialize I2C
	I2C_GPIO_Init();
	I2C_Initialization();
	
	
	int i;
	char message[6];
	uint8_t SlaveAddress;
	uint8_t Data_Receive;
	uint8_t Data_Send;
	while(1) {	
		// Determine Slave Address
		//
		// Note the "<< 1" must be present because bit 0 is treated as a don't care in 7-bit addressing mode
		SlaveAddress = ((uint8_t)0b1001000) << 1; // is it ok if its in hex ?
		
		// TODO - Get Temperature
			Data_Send = 0x00; //00h is the command to send the data 
			I2C_SendData(I2C1, SlaveAddress,&Data_Send,1);
	
		// First, send a command to the sensor for reading the temperature
		// Next, get the measurement
		//Read //stores as a 
			I2C_ReceiveData( I2C1,SlaveAddress,&Data_Receive,1);
		
			 // convertng to a signed number
		
			sprintf(message,"%6d",Data_Receive);
		// TODO - Print Temperature to LCD
		LCD_DisplayString(message);
		// Some delay
		for(i = 0; i < 50000; ++i); 
	}
}
